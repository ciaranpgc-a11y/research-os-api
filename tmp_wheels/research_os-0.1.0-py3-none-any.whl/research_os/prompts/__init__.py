"""Prompt templates and builders."""
